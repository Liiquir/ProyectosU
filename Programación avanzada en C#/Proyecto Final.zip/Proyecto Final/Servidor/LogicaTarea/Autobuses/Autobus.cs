﻿using LogicaTarea.Terminales;

namespace LogicaTarea
{
    public class Autobus
    {
        public int NUM_IDENTIFICACION  { get; set; }
        public string NUM_PLACA { get; set; }
        public string DSC_MARCA { get; set; }
        public int NUM_MODELO { get; set; }
        public int NUM_CAPACIDAD { get; set; }
        public bool BOL_ESTADO { get; set; }

        

        public Autobus()
        {
        }
        
    }
}
